# financial-services-tej（TEJ 台股投顧 AI marketplace）

改編自 `anthropics/financial-services`，資料源換成 TEJ MCP。三個 plugin：

| Plugin | 層級 | 做什麼 |
|---|---|---|
| earnings-reviewer-tej | 報告層 | 單一標的 → 13 區塊台股投顧報告＋AI house 評等/目標價 |
| market-researcher-tej | 發現層 | 產業/主題 → 產業概況、競爭格局、可比公司、候選標的清單 |
| meeting-prep-tej | 速覽層 | 個股/投組 → 1-2 頁簡易紀錄 |

## 安裝（marketplace 方式）

1. 把本 repo 推到 GitHub（見下方「發佈」）。
2. 在 Cowork/Claude Code：Plugins → Add → Add marketplace，貼上本 repo 的 GitHub 網址（owner/repo 或 https://github.com/owner/repo），Sync。
   - CLI 對應指令：`/plugin marketplace add <owner/repo>`。
3. Sync 後三個 plugin 會出現在清單，逐一 Install/Enable。
4. **接上 TEJ MCP**：各 plugin 的 `.mcp.json` 內 URL 為示意值，需依實際 TEJ MCP 部署填入，agent 才叫得到 `mcp__tejapi__*` 工具。

## 發佈到 GitHub

```bash
cd financial-services-tej
git init && git add . && git commit -m "init: TEJ 投顧 marketplace v0.1.0"
git branch -M main
git remote add origin https://github.com/<owner>/financial-services-tej.git
git push -u origin main
```

推完後，Add marketplace 貼 `https://github.com/<owner>/financial-services-tej` 即可。

## 版本

marketplace.json 的 metadata.version 目前 0.1.0；有改動時 bump 版本，使用者用 `/plugin marketplace update` 更新。
